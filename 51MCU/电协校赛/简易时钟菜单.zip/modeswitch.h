#ifndef __MODESWITCH_H__
#define __MODESWITCH_H__
void mode_switch() ;
#endif 