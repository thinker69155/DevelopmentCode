#ifndef __DELAY_H__
#define __DELAY_H__
unsigned char key_scan();	
#endif 