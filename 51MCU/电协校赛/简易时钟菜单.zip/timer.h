#ifndef __TIMER_H__
#define __TIMER_H__
void Timer0_Init();
#endif 