#ifndef __TIMEUPDATE_H__
#define __TIMEUPDATE_H__
void handle_time_update();
#endif 