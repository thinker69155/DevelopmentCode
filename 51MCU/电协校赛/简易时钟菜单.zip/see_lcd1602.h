#ifndef __DELAY_H__
#define __DELAY_H__
void see_lcd1602();	
#endif 