#ifndef __HANDLEMODE_H__
#define __HANDLEMODE_H__
void handle_calendar_mode(unsigned char key);
void handle_countdown_mode(unsigned char key);
void handle_stopwatch_mode(unsigned char key);
void handle_view_record_mode(unsigned char key);
#endif 